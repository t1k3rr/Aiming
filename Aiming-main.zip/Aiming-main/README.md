# Aiming
 A module that helps you create "Aiming" scripts.

[docs](https://stefanuk12.github.io/Aiming/)
