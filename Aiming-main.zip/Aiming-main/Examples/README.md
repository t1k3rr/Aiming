## Universal Silent Aim
This was inspired by [this project](https://github.com/Averiias/Universal-SilentAim)

### Tested Games
* [Da Hood](https://www.roblox.com/games/2788229376/) (`Hit`)
* [Prison Life](https://www.roblox.com/games/155615604/) (`Hit,Target,FindPartOnRay`)