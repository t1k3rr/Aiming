--[[
    Information:

    - Futuretops: Rework (https://www.roblox.com/games/5169051062/)
    - This is for the VIP servers
]]

-- // Run other one
return loadstring(game:HttpGet("https://raw.githubusercontent.com/Stefanuk12/Aiming/main/GamePatches/Module/5169051062.lua"))()